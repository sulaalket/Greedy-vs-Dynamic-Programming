package com.example.greedy;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

class Item {
    int value;
    int size;

    public Item(int value, int size) {
        this.value = value;
        this.size = size;
    }
}

public class MaximumValueBagHistogram extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Random random = new Random();
        int n = random.nextInt(10) + 1; // Number of items (adjust the range as needed)
        int C = random.nextInt(20) + 1; // Capacity of the bag (adjust the range as needed)

        List<Item> items = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int value = random.nextInt(10) + 1; // Value of the item (adjust the range as needed)
            int size = random.nextInt(10) + 1; // Size of the item (adjust the range as needed)
            items.add(new Item(value, size));
        }

        // Sort items by decreasing values
        Collections.sort(items, Comparator.comparingInt((Item item) -> item.value).reversed());

        List<Item> bag1 = new ArrayList<>();
        List<Item> bag2 = new ArrayList<>();

        // Greedy filling of the two bags
        for (Item item : items) {
            if (item.size <= C) {
                bag1.add(item);
                C -= item.size;
            } else {
                bag2.add(item);
            }
        }

        // Generate the histogram data based on item sizes in Bag 1
        int[] histogramData = new int[10]; // Assuming size range from 1 to 10
        for (Item item : bag1) {
            int size = item.size;
            histogramData[size - 1]++; // Increment the count for the corresponding size
        }

        // Create the JavaFX chart
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);

        // Prepare the histogram data for the chart
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        ObservableList<XYChart.Data<String, Number>> chartData = FXCollections.observableArrayList();
        for (int i = 0; i < histogramData.length; i++) {
            chartData.add(new XYChart.Data<>(String.valueOf(i + 1), histogramData[i]));
        }
        series.setData(chartData);

        // Add the series to the chart
        barChart.getData().add(series);

        // Create and show the JavaFX scene
        Scene scene = new Scene(barChart, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Item Size Histogram");
        primaryStage.show();
    }
}
